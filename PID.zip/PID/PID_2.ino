// ============================================
// STAGE 2: PPR Calibration
// Rotate motor exactly 1 full revolution
// Count pulses → that is your real PPR
// ============================================

#define RPWM 9
#define ENCODER_A 2
#define ENCODER_B 3

volatile long encoderCount = 0;
bool motorRunning = false;
bool calibrationDone = false;

void encoderISR() {
  if (digitalRead(ENCODER_B) == HIGH) {
    encoderCount++;
  } else {
    encoderCount--;
  }
}

void setup() {
  Serial.begin(9600);
  pinMode(RPWM, OUTPUT);
  pinMode(ENCODER_A, INPUT_PULLUP);
  pinMode(ENCODER_B, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(ENCODER_A), encoderISR, RISING);

  Serial.println("=== Stage 2: PPR Calibration ===");
  Serial.println("Instructions:");
  Serial.println("1. Mark a point on your motor shaft with a pen");
  Serial.println("2. Send 'S' in Serial Monitor to START motor");
  Serial.println("3. When shaft completes ONE full rotation, send 'X' to STOP");
  Serial.println("4. Read the PPR value shown");
}

void loop() {
  if (Serial.available()) {
    char cmd = Serial.read();

    // Start motor
    if (cmd == 'S' || cmd == 's') {
      encoderCount = 0;
      motorRunning = true;
      analogWrite(RPWM, 80); // Slow speed for accurate calibration
      Serial.println("Motor started! Watch the shaft...");
      Serial.println("Send 'X' when exactly ONE full rotation completes.");
    }

    // Stop motor and show PPR
    if (cmd == 'X' || cmd == 'x') {
      analogWrite(RPWM, 0);
      motorRunning = false;

      Serial.println("==============================");
      Serial.print("Your PPR = ");
      Serial.println(abs(encoderCount));
      Serial.println("Note this value for Stage 3 PID code!");
      Serial.println("==============================");
    }
  }
}