// ============================================
// STAGE 1: Motor + Encoder Test
// Verify both motor and encoder work correctly
// Before attempting PID
// ============================================

#define RPWM 9        // PWM pin to BTS7960
#define R_EN 10       // Enable pin (if not hardwired to 5V)

#define ENCODER_A 2   // Encoder Channel A → Interrupt pin
#define ENCODER_B 3   // Encoder Channel B → Interrupt pin

volatile long encoderCount = 0;  // Counts encoder pulses
long lastCount = 0;
float rpm = 0;

// ── Interrupt Service Routine ──
// Called every time encoder A rises
void IRAM_ATTR encoderISR() {
  if (digitalRead(ENCODER_B) == HIGH) {
    encoderCount++;   // Forward
  } else {
    encoderCount--;   // Backward
  }
}

void setup() {
  Serial.begin(9600);

  // Motor pins
  pinMode(RPWM, OUTPUT);

  // Encoder pins
  pinMode(ENCODER_A, INPUT_PULLUP);
  pinMode(ENCODER_B, INPUT_PULLUP);

  // Attach interrupt on Encoder A
  attachInterrupt(digitalPinToInterrupt(ENCODER_A), encoderISR, RISING);

  Serial.println("=== Stage 1: Motor + Encoder Test ===");
  Serial.println("Motor spinning at 50% speed...");

  // Spin motor at 50%
  analogWrite(RPWM, 128);
}

void loop() {
  // Calculate RPM every 500ms
  delay(500);

  long currentCount = encoderCount;
  long pulses = currentCount - lastCount;
  lastCount = currentCount;

  // RPM formula:
  // pulses in 500ms → multiply by 2 for per second → divide by PPR → multiply by 60
  // We use 360 as estimated PPR — will calibrate in Stage 2
  float estimatedPPR = 360.0;
  rpm = (pulses / estimatedPPR) * 2.0 * 60.0;

  Serial.print("Encoder Count: ");
  Serial.print(currentCount);
  Serial.print("  |  RPM: ");
  Serial.println(rpm);
}