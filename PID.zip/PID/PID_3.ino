// ============================================
// STAGE 3: Full PID Speed + Position Control
// Speed PID  → maintains target RPM
// Position PID → rotates exact degrees
// ============================================

#define RPWM 9
#define ENCODER_A 2
#define ENCODER_B 3

// ── Replace with your PPR from Stage 2 ──
#define PPR 1420

// ── PID Gains — tune these ──
float Kp_speed = 1.0;
float Ki_speed = 0.8;
float Kd_speed = 0.0;

float Kp_pos = 3.0;
float Ki_pos = 0.0;
float Kd_pos = 0.2;

// ── Encoder ──
volatile long encoderCount = 0;

// ── PID variables ──
float speedError = 0, speedPrevError = 0, speedIntegral = 0;
float posError = 0,   posPrevError = 0,   posIntegral = 0;

// ── Timing ──
unsigned long lastTime = 0;
long lastEncoderCount = 0;

// ── Mode ──
// 0 = Speed Control
// 1 = Position Control
int mode = 0;

// ── Targets ──
float targetRPM = 50.0;          // Target speed in RPM
long targetPosition = 0;         // Target position in encoder pulses

void encoderISR() {
  if (digitalRead(ENCODER_B) == HIGH) {
    encoderCount++;
  } else {
    encoderCount--;
  }
}

// ── Apply PWM safely ──
void setMotorPWM(int pwm) {
  pwm = constrain(pwm, 0, 255);
  analogWrite(RPWM, pwm);
}

// ── Degrees to pulses ──
long degreesToPulses(float degrees) {
  return (long)((degrees / 360.0) * PPR);
}

void setup() {
  Serial.begin(9600);
  pinMode(RPWM, OUTPUT);
  pinMode(ENCODER_A, INPUT_PULLUP);
  pinMode(ENCODER_B, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(ENCODER_A), encoderISR, RISING);

  Serial.println("=== Stage 3: PID Motor Control ===");
  Serial.println("Commands:");
  Serial.println("  S<value>  → Set speed RPM    (e.g. S50)");
  Serial.println("  P<value>  → Set position deg (e.g. P360)");
  Serial.println("  X         → Stop motor");
  Serial.println("  R         → Reset encoder count");
  Serial.println("===================================");

  lastTime = millis();
}

void loop() {
  // ── Read Serial Commands ──
  if (Serial.available()) {
    String input = Serial.readStringUntil('\n');
    input.trim();
    char cmd = input.charAt(0);
    float value = input.substring(1).toFloat();

    if (cmd == 'S' || cmd == 's') {
      mode = 0;
      targetRPM = value;
      speedIntegral = 0;
      Serial.print("Speed mode → Target RPM: ");
      Serial.println(targetRPM);
    }

    if (cmd == 'P' || cmd == 'p') {
      mode = 1;
      encoderCount = 0;   // Reset position
      targetPosition = degreesToPulses(value);
      posIntegral = 0;
      Serial.print("Position mode → Target degrees: ");
      Serial.print(value);
      Serial.print(" = ");
      Serial.print(targetPosition);
      Serial.println(" pulses");
    }

    if (cmd == 'X' || cmd == 'x') {
      setMotorPWM(0);
      Serial.println("Motor stopped.");
    }

    if (cmd == 'R' || cmd == 'r') {
      encoderCount = 0;
      Serial.println("Encoder reset to 0.");
    }
  }

  // ── PID Loop runs every 100ms ──
  unsigned long now = millis();
  if (now - lastTime >= 100) {
    float dt = (now - lastTime) / 1000.0; // seconds
    lastTime = now;

    // ── Speed PID ──
    if (mode == 0) {
      long currentCount = encoderCount;
      long pulses = currentCount - lastEncoderCount;
      lastEncoderCount = currentCount;

      float currentRPM = (pulses / (float)PPR) * (60.0 / dt);

      speedError    = targetRPM - currentRPM;
      speedIntegral += speedError * dt;
      float speedDerivative = (speedError - speedPrevError) / dt;
      speedPrevError = speedError;

      float output = (Kp_speed * speedError)
                   + (Ki_speed * speedIntegral)
                   + (Kd_speed * speedDerivative);

      setMotorPWM((int)output);

      // ── Serial Plotter output ──
      Serial.print("Target:");
      Serial.print(targetRPM);
      Serial.print(" RPM:");
      Serial.print(currentRPM);
      Serial.print(" PWM:");
      Serial.println((int)constrain(output, 0, 255));
    }

    // ── Position PID ──
    if (mode == 1) {
      long currentPos = encoderCount;

      posError    = targetPosition - currentPos;
      posIntegral += posError * dt;
      float posDerivative = (posError - posPrevError) / dt;
      posPrevError = posError;

      float output = (Kp_pos * posError)
                   + (Ki_pos * posIntegral)
                   + (Kd_pos * posDerivative);

      // Stop if close enough (within 5 pulses)
      if (abs(posError) <= 5) {
        setMotorPWM(0);
        Serial.println("Position reached!");
      } else {
        setMotorPWM((int)output);
      }

      // ── Serial Plotter output ──
      Serial.print("Target:");
      Serial.print(targetPosition);
      Serial.print(" Position:");
      Serial.print(currentPos);
      Serial.print(" Error:");
      Serial.println(posError);
    }
  }
}